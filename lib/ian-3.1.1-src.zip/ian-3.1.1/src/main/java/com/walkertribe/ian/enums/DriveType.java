package com.walkertribe.ian.enums;

/**
 * The two types of ship drives.
 * @author rjwut
 */
public enum DriveType {
	WARP, JUMP
}