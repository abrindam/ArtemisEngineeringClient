package com.walkertribe.ian.enums;

/**
 * The types of audio notification that the comm officer can receive.
 * @author rjwut
 */
public enum AudioMode {
	PLAYING,
	INCOMING
}