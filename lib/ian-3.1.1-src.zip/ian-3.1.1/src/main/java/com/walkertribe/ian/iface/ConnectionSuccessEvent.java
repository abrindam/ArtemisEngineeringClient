package com.walkertribe.ian.iface;

/**
 * An event that gets thrown when IAN successfully connects to a remote machine.
 * @author rjwut
 */
public class ConnectionSuccessEvent extends ConnectionEvent {
	// no additional members
}