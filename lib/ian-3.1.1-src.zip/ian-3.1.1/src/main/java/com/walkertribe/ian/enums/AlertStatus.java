package com.walkertribe.ian.enums;

/**
 * The alert status of a player ship.
 * @author rjwut
 */
public enum AlertStatus {
	NORMAL,
	RED
}